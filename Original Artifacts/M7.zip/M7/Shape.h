#pragma once
class Shape
{
public:
	
};

