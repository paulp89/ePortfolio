#include "Light.h"



Light::Light()
{
}
